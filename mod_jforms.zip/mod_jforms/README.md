jForms Module
======
A slick AJAX contact form using Joomla's inbuilt jForms.